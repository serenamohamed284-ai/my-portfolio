document.addEventListener("DOMContentLoaded", () => {
  const menuBtn = document.getElementById("menuBtn");
  const mobileNav = document.getElementById("mobileNav");

  if (menuBtn && mobileNav) {
    menuBtn.addEventListener("click", () => {
      mobileNav.classList.toggle("open");
      menuBtn.innerHTML = mobileNav.classList.contains("open")
        ? '<i class="fa-solid fa-xmark"></i>'
        : '<i class="fa-solid fa-bars"></i>';
    });
  }

  // Reveal elements when they enter the viewport
  const observer = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) entry.target.classList.add("show");
    });
  }, { threshold: 0.08 });

  document.querySelectorAll(".reveal").forEach(el => observer.observe(el));

  // Reading progress bar
  const progress = document.getElementById("scrollProgress");
  window.addEventListener("scroll", () => {
    const scrollTop = window.scrollY;
    const height = document.documentElement.scrollHeight - window.innerHeight;
    progress.style.width = height > 0 ? `${(scrollTop / height) * 100}%` : "0%";
  });

  // Project filtering
  const filters = document.querySelectorAll(".filter");
  const projects = document.querySelectorAll(".project-card");

  filters.forEach(button => {
    button.addEventListener("click", () => {
      filters.forEach(btn => btn.classList.remove("active"));
      button.classList.add("active");
      const filter = button.dataset.filter;

      projects.forEach(project => {
        const categories = project.dataset.category || "";
        if (filter === "all" || categories.includes(filter)) {
          project.classList.remove("hidden-card");
        } else {
          project.classList.add("hidden-card");
        }
      });
    });
  });

  // Contact form validation
  const form = document.getElementById("contactForm");
  const output = document.getElementById("formMessage");

  if (form && output) {
    form.addEventListener("submit", (event) => {
      event.preventDefault();
      const name = document.getElementById("name").value.trim();
      const email = document.getElementById("email").value.trim();
      const subject = document.getElementById("subject").value.trim();
      const message = document.getElementById("message").value.trim();

      if (!name || !email || !subject || !message) {
        output.className = "error";
        output.textContent = "Please complete all fields.";
        return;
      }

      if (!/^[^\\s@]+@[^\\s@]+\\.[^\\s@]+$/.test(email)) {
        output.className = "error";
        output.textContent = "Please enter a valid email address.";
        return;
      }

      output.className = "success";
      output.textContent = "Your message is valid. To receive real messages, connect this form to a backend or form service.";
      form.reset();
    });
  }
});