# Hibo Mohamed Sharif Portfolio

Open `index.html` in a browser.

Pages:
- Home
- About
- Skills
- Projects
- Contact

Contact email:
serenamohamed284@gmail.com

The contact email is already connected with a mailto link.
GitHub and LinkedIn buttons currently point to their homepages because the user's personal profile URLs were not provided.
